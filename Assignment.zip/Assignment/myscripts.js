hamburger = document.querySelector(".hamburger");
	hamburger.onClick = function() {
		navBar = document.querySelector(".nav-bar");
		navbar.classList.toggle("active");